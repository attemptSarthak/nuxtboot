<template>
  <div class="dataview">
    <el-table
      :data="tasks"
      style="width: 100%">
      <el-table-column
        prop="id"
        label="ID"
        width="50">
      </el-table-column>
      <el-table-column
        prop="taskName"
        label="Task Name">
      </el-table-column>
      <el-table-column
        prop="status"
        label="Status">
      </el-table-column>
      <el-table-column label="Operations">
      <template #default="scope">
        <el-button size="small" @click="handleEdit(scope.$index, scope.row)"
          >Edit</el-button
        >
        <el-button
          size="small"
          type="danger"
          @click="handleDelete(scope.$index, scope.row)"
          >Delete</el-button
        >
      </template>
    </el-table-column>
    </el-table>

    <div class="button-bar">
      <el-button @click="addUserVisible = true">Add user</el-button>
    </div>

    <el-dialog title="Add a user" :visible.sync="addUserVisible">
      <el-form ref="userForm" :model="task" :rules="userRules" label-width="200px">
        <el-form-item label="Task Name" prop="taskName">
          <el-input v-model="task.taskName"></el-input>
        </el-form-item>
        <el-form-item label="Status" prop="status">
          <el-input v-model="task.status"></el-input>
        </el-form-item>
        <el-form-item>
          <el-button type="primary" @click="addUser('userForm')">Add</el-button>
          <el-button @click="addUserVisible = false">Cancel</el-button>
        </el-form-item>
      </el-form>
    </el-dialog>
  </div>
</template>

<script>
export default {
  name: 'tasks',

  layout: 'with-navbar',

  data() {
    return {
      addUserVisible: false,
      task: {
        taskName: '',
        status: ''
      },
      userRules: {
        taskName: [
          { required: true, message: 'Please set a taskName', trigger: 'blur' }
        ],
        status: [
          { required: true, message: 'Please set a status', trigger: 'blur' }
        ]
      },
      tasks: []
    }
  },

  mounted() {
    this.loadTasks()
  },

  methods: {
    loadTasks() {
      this.$axios.$get('/api/task')
        .then(data => {
          this.tasks = data
        })
    },

    addUser(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.addUserVisible = false
          this.$axios.$post('/api/addTask?taskName=' + this.task.taskName + '&status=' + this.task.status)
            .then (resp => {
              this.$message({
                type: 'success',
                message: 'User added with success'
              })
              this.user = { taskName: '', status: '' }
              this.loadTasks()
            })
            .catch (err => {
              this.$message({
                type: 'error',
                message: 'An error occured: ' + err
              })
            })
        }
        return valid
      })
    }
  }
}
</script>
