# backend

Start the application:
```bash
mvn spring-boot:run
```