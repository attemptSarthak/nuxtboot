package com.example.demo;



import java.time.Duration;
import java.util.Arrays;
import java.util.List;

import javax.management.relation.RelationNotFoundException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.scheduling.config.Task;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api")
public class TodoController {
	@Autowired
    TodoTaskRepository repository;
	@Autowired
	ApplicationEventPublisher publisher;

   
    @RequestMapping(path = "/addTask", method = RequestMethod.POST)
   
    public Mono<Long> addTasks(@RequestParam String taskName, @RequestParam String status){
    	
        final TodoTask task = new TodoTask(taskName, status);
    	return 
    	repository.save(task).doOnSuccess(item -> publishCatalogueItemEvent("Created", item)).flatMap(item -> Mono.just(item.getId()));
        
    }
    
    @PostMapping("/updateTask")
    public Flux<TodoTask> updateCatalogueItem(
        
         @RequestBody TodoTask catalogueItem)  {
    	Mono<TodoTask> catalogueItemfromDB = getItemById(catalogueItem.getId());

        catalogueItemfromDB.subscribe(
            value -> {
                value.setTaskName(catalogueItem.getTaskName());
                value.setStatus(catalogueItem.getStatus());

                repository
                    .save(value)
                    .doOnSuccess(item -> publishCatalogueItemEvent("UPDATED", item))
                    .subscribe();
            });
        return repository.findAll();
    }
    
    @GetMapping("/task")
    public Flux<TodoTask> getTasks(){
    	
       return repository.findAll();
    }
    
    private final void publishCatalogueItemEvent(String eventType, TodoTask item) {
        this.publisher.publishEvent(new TaskItemEvent(eventType, item));
    }
    private Mono<TodoTask> getItemById(Long skuNumber) {
        return repository.findById(skuNumber).switchIfEmpty(Mono.defer(() -> Mono.error(new RelationNotFoundException(
                String.format("Catalogue Item not found for the provided SKU :: %s" , skuNumber)))));
    }
}