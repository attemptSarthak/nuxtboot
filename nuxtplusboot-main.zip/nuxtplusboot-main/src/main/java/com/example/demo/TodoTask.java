package com.example.demo;

import org.springframework.data.annotation.Id;

public class TodoTask {

    @Id
    private Long id;

    private  String taskName;

    private  String status;

    public TodoTask(String taskName, String status) {
        this.taskName = taskName;
        this.status = status;
    }

    public Long getId() {
        return this.id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getTaskName() {
        return this.taskName;
    }

    public String getStatus() {
        return this.status;
    }

    @Override
    public String toString() {
        return String.format(
            "TodoTask[id=%d, firstName='%s', lastName='%s']",
            id, taskName, status);
    }
}
